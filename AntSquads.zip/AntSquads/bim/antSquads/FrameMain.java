package bim.antSquads;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.Vector;

public class FrameMain extends Frame
implements ActionListener, MouseListener, MouseMotionListener {
  static int ANT_COLOR_COUNT=5;
  static int ANT_COLOR_RED=0;
  static int ANT_COLOR_GREEN=1;
  static int ANT_COLOR_BLUE=2;
  static int ANT_COLOR_YELLOW=3;
  static int ANT_COLOR_GRAY=4;
  static Color ANT_COLORS[]={Color.red, Color.green, Color.blue, Color.yellow, Color.gray};

/*
  static int ANT_COLOR_COUNT=9;
  static int ANT_COLOR_RED=0;
  static int ANT_COLOR_GREEN=1;
  static int ANT_COLOR_BLUE=2;
  static int ANT_COLOR_YELLOW=3;
  static int ANT_COLOR_CYAN=4;
  static int ANT_COLOR_MAGENTA=5;
  static int ANT_COLOR_GRAY=6;
  static int ANT_COLOR_ORANGE=7;
  static int ANT_COLOR_PINK=8;
  static Color ANT_COLORS[]={Color.red, Color.green, Color.blue, Color.yellow, Color.cyan, Color.magenta, Color.gray, Color.orange, Color.pink};
*/

  AntCanvas aCanv=new AntCanvas();

  static int intAntMovesPerTurn=7;
  static int intMinimumAntAlignment=4;
  static int intPointsPerAnt=5;
  static int intAntSpawnPerTurn=15;

  Button btnNewGame=new Button("New Game");
  Button btnEndTurn=new Button("End Turn");
  Label lblPoints=new Label("             ");
  Label lblMoves=new Label("             ");

  boolean blnGameOver=true;

  public static void main(String args[]) {
    FrameMain mFrame=new FrameMain();

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

    mFrame.setSize(dimScreen.width, dimScreen.height-50);
    mFrame.setVisible(true);

    mFrame.aCanv.initializeSquareWidth();
  }

  public FrameMain() {
    super();

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    add("Center", aCanv);
    aCanv.addMouseListener(this);
    aCanv.addMouseMotionListener(this);

    Panel pnlTemp=new Panel();
    pnlTemp.add(btnNewGame);
    btnNewGame.addActionListener(this);
    pnlTemp.add(btnEndTurn);
    btnEndTurn.addActionListener(this);
    pnlTemp.add(new Label("Points:"));
    pnlTemp.add(lblPoints);
    pnlTemp.add(new Label("Moves:"));
    pnlTemp.add(lblMoves);

    add("South", pnlTemp);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnNewGame) {
      for(int i=0;i<aCanv.blnOccupied.length;i++) {
        for(int ia=0;ia<aCanv.blnOccupied[0].length;ia++) {
          aCanv.blnOccupied[i][ia]=false;
        }
      }

      lblPoints.setText("0");
      lblMoves.setText(String.valueOf(intAntMovesPerTurn));

      checkForAlignment(false);

      aCanv.repaint();

      blnGameOver=false;
    }
    else if(evSource==btnEndTurn) {
      if(blnGameOver)
        return;

      checkForAlignment(false);
    }
  }

  public void mouseEntered(MouseEvent me) {
  }

  public void mouseExited(MouseEvent me) {
  }

  public void mousePressed(MouseEvent me) {
  }

  public void mouseReleased(MouseEvent me) {
  }

  public void mouseClicked(MouseEvent me) {
    if(blnGameOver)
      return;

    int intMEX=me.getX();
    int intMEY=me.getY();

    int intAntLocationX=intMEX/aCanv.intSquareWidth;
    int intAntLocationY=intMEY/aCanv.intSquareWidth;

    if(me.getClickCount()==2) {
//      checkForAlignment(false);
    }
    else {
       int intSquareX=intAntLocationX;
       int intSquareY=intAntLocationY;

       if(intSquareX<0) {
         return;
       }

       if(intSquareX>=aCanv.intSquaresHorizontal) {
         return;
       }

       if(intSquareY<0) {
         return;
       }

      if(intSquareY>=aCanv.intSquaresVertical) {
        return;
      }

      if(aCanv.blnOccupied[intAntLocationX][intAntLocationY]) {
        aCanv.intMouseSelectedX=intAntLocationX;
        aCanv.intMouseSelectedY=intAntLocationY;

        aCanv.repaint();
      }
      else {
        if(aCanv.intMouseSelectedX!=-1) {
          if(intAntLocationX>=(aCanv.intMouseSelectedX-1) & intAntLocationX<=(aCanv.intMouseSelectedX+1)) {
            if(intAntLocationY>=(aCanv.intMouseSelectedY-1) & intAntLocationY<=(aCanv.intMouseSelectedY+1)) {

//              int intSquareX=intAntLocationX;
//              int intSquareY=intAntLocationY;

              if(intSquareX<0) {
                return;
              }

              if(intSquareX>=aCanv.intSquaresHorizontal) {
                return;
              }

              if(intSquareY<0) {
                return;
              }

              if(intSquareY>=aCanv.intSquaresVertical) {
                return;
              }

              aCanv.blnOccupied[intAntLocationX][intAntLocationY]=true;
              aCanv.blnOccupied[aCanv.intMouseSelectedX][aCanv.intMouseSelectedY]=false;
              aCanv.intOccupied[intAntLocationX][intAntLocationY]=aCanv.intOccupied[aCanv.intMouseSelectedX][aCanv.intMouseSelectedY];

              aCanv.intMouseSelectedX=intAntLocationX;
              aCanv.intMouseSelectedY=intAntLocationY;

              --aCanv.intMouseMovesLeft;

              lblMoves.setText(String.valueOf(aCanv.intMouseMovesLeft));

              if(aCanv.intMouseMovesLeft==0) {
                checkForAlignment(false);
              }
              else {
                aCanv.repaint();
              }
            }
          }
        }
      }
    }
  }

  public void mouseMoved(MouseEvent me) {
    if(blnGameOver)
      return;

    int intMEX=me.getX();
    int intMEY=me.getY();

    int intSquareX=intMEX/aCanv.intSquareWidth;
    int intSquareY=intMEY/aCanv.intSquareWidth;

    if(intSquareX<0) {
      if(aCanv.intMouseEnteredX==-1)
        return;

      aCanv.intMouseEnteredX=-1;
      aCanv.intMouseEnteredY=-1;

      aCanv.repaint();

      return;
    }

    if(intSquareX>=aCanv.intSquaresHorizontal) {
      if(aCanv.intMouseEnteredX==-1)
        return;

      aCanv.intMouseEnteredX=-1;
      aCanv.intMouseEnteredY=-1;

      aCanv.repaint();

      return;
    }

    if(intSquareY<0) {
      if(aCanv.intMouseEnteredX==-1)
        return;

      aCanv.intMouseEnteredX=-1;
      aCanv.intMouseEnteredY=-1;

      aCanv.repaint();

      return;
    }

    if(intSquareY>=aCanv.intSquaresVertical) {
      if(aCanv.intMouseEnteredX==-1)
        return;

      aCanv.intMouseEnteredX=-1;
      aCanv.intMouseEnteredY=-1;

      aCanv.repaint();

      return;
    }

    if(aCanv.intMouseEnteredX==intSquareX & aCanv.intMouseEnteredY==intSquareY) {
      return;
    }

//    aCanv.intLastMouseEnteredX=aCanv.intMouseEnteredX;
//    aCanv.intLastMouseEnteredY=aCanv.intMouseEnteredY;

    aCanv.intMouseEnteredX=intSquareX;
    aCanv.intMouseEnteredY=intSquareY;

//    aCanv.blnChangedMouseEntered=true;

    aCanv.repaint();
  }

  public void mouseDragged(MouseEvent me) {
  }

  public void checkForAlignment(boolean blnRecursive) {
    int intTotalAnts=0;

    boolean blnAligned[][]=new boolean[aCanv.blnOccupied.length][aCanv.blnOccupied[0].length];

    for(int i=0;i<blnAligned.length;i++) {
      for(int ia=0;ia<blnAligned[0].length;ia++) {
        blnAligned[i][ia]=false;
      }
    }

//Directions:
//0=North
//1=East
//2=South
//3=West
    for(int i=0;i<blnAligned.length;i++) {
      for(int ia=0;ia<blnAligned[0].length;ia++) {
        if(!aCanv.blnOccupied[i][ia])
          continue;

        if(i==0) {
          if(ia==0) {
            intTotalAnts+=checkForAlignmentDirection(1, i, ia, blnAligned);
            intTotalAnts+=checkForAlignmentDirection(2, i, ia, blnAligned);
          }
          else if(ia==(blnAligned.length-intMinimumAntAlignment)) {
            intTotalAnts+=checkForAlignmentDirection(0, i, ia, blnAligned);
            intTotalAnts+=checkForAlignmentDirection(1, i, ia, blnAligned);
          }
          else {
            intTotalAnts+=checkForAlignmentDirection(0, i, ia, blnAligned);
            intTotalAnts+=checkForAlignmentDirection(1, i, ia, blnAligned);
            intTotalAnts+=checkForAlignmentDirection(2, i, ia, blnAligned);
          }
        }
        else if(i==(blnAligned.length-intMinimumAntAlignment)) {
          if(ia==0) {
            intTotalAnts+=checkForAlignmentDirection(3, i, ia, blnAligned);
            intTotalAnts+=checkForAlignmentDirection(2, i, ia, blnAligned);
          }
          else if(ia==(blnAligned.length-intMinimumAntAlignment)) {
            intTotalAnts+=checkForAlignmentDirection(0, i, ia, blnAligned);
            intTotalAnts+=checkForAlignmentDirection(3, i, ia, blnAligned);
          }
          else {
            intTotalAnts+=checkForAlignmentDirection(0, i, ia, blnAligned);
            intTotalAnts+=checkForAlignmentDirection(2, i, ia, blnAligned);
            intTotalAnts+=checkForAlignmentDirection(3, i, ia, blnAligned);
          }
        }
        else {
          if(ia==0) {
            intTotalAnts+=checkForAlignmentDirection(1, i, ia, blnAligned);
            intTotalAnts+=checkForAlignmentDirection(2, i, ia, blnAligned);
            intTotalAnts+=checkForAlignmentDirection(3, i, ia, blnAligned);
          }
          else if(ia==(blnAligned.length-intMinimumAntAlignment)) {
            intTotalAnts+=checkForAlignmentDirection(0, i, ia, blnAligned);
            intTotalAnts+=checkForAlignmentDirection(1, i, ia, blnAligned);
            intTotalAnts+=checkForAlignmentDirection(3, i, ia, blnAligned);
          }
          else {
            int intColor=aCanv.intOccupied[i][ia];

            int intMatchWest=i-1;
            for(;intMatchWest>=0;intMatchWest--) {
              if(aCanv.blnOccupied[intMatchWest][ia]) {
                if(aCanv.intOccupied[intMatchWest][ia]!=intColor) {
                  break;
                }
              }
              else {
                break;
              }
            }
            ++intMatchWest;

            int intMatchEast=i+1;
            for(;intMatchEast<aCanv.blnOccupied.length;intMatchEast++) {
              if(aCanv.blnOccupied[intMatchEast][ia]) {
                if(aCanv.intOccupied[intMatchEast][ia]!=intColor) {
                  break;
                }
              }
              else {
                break;
              }
            }
            --intMatchEast;


            int intMatchNorth=ia-1;
            for(;intMatchNorth>=0;intMatchNorth--) {
              if(aCanv.blnOccupied[i][intMatchNorth]) {
                if(aCanv.intOccupied[i][intMatchNorth]!=intColor) {
                  break;
                }
              }
              else {
                break;
              }
            }
            ++intMatchNorth;

            int intMatchSouth=ia+1;
            for(;intMatchSouth<aCanv.blnOccupied[0].length;intMatchSouth++) {
              if(aCanv.blnOccupied[i][intMatchSouth]) {
                if(aCanv.intOccupied[i][intMatchSouth]!=intColor) {
                  break;
                }
              }
              else {
                break;
              }
            }
            --intMatchSouth;

            int intHorizontalAlignment=intMatchEast-intMatchWest+1;
            int intVerticalAlignment=intMatchSouth-intMatchNorth+1;

            int intAnts=0;

            if(intHorizontalAlignment>=intMinimumAntAlignment) {
              for(int iz=intMatchWest;iz<=intMatchEast;iz++) {
                if(!blnAligned[iz][ia]) {
                  blnAligned[iz][ia]=true;

                  ++intAnts;
                }
              }
            }

            if(intVerticalAlignment>=intMinimumAntAlignment) {
              for(int iz=intMatchNorth;iz<=intMatchSouth;iz++) {
                if(!blnAligned[i][iz]) {
                  blnAligned[i][iz]=true;

                  ++intAnts;
                }
              }
            }

            int intPoints=Integer.parseInt(lblPoints.getText());

            intPoints+=(intAnts*intPointsPerAnt);

            lblPoints.setText(String.valueOf(intPoints));

            intTotalAnts+=intAnts;
          }
        }
      }
    }

    for(int i=0;i<blnAligned.length;i++) {
      for(int ia=0;ia<blnAligned[0].length;ia++) {
        if(blnAligned[i][ia]) {
          aCanv.blnOccupied[i][ia]=false;
        }
      }
    }

    Vector vecLocations=new Vector();

    for(int intX=0;intX<aCanv.blnOccupied.length;intX++) {
      for(int intY=0;intY<aCanv.blnOccupied[0].length;intY++) {
        if(!aCanv.blnOccupied[intX][intY]) {
          vecLocations.addElement(new XandY(intX, intY));
        }
      }
    }

    if(!blnRecursive || (blnRecursive & intTotalAnts>0)) {
      if(vecLocations.size()<intAntSpawnPerTurn) {
        lblMoves.setText("-");

        blnGameOver=true;

        return;
      }

      for(int i=0;i<intAntSpawnPerTurn;i++) {
        int intLocation=Double.valueOf(Math.floor(Math.random()*Integer.valueOf(vecLocations.size()).doubleValue())).intValue();

        XandY xAndY=(XandY)vecLocations.elementAt(intLocation);

        vecLocations.removeElementAt(intLocation);

        int intColor=Double.valueOf(Math.floor(Math.random()*Integer.valueOf(ANT_COLOR_COUNT).doubleValue())).intValue();

        aCanv.blnOccupied[xAndY.intX][xAndY.intY]=true;
        aCanv.intOccupied[xAndY.intX][xAndY.intY]=intColor;
      }

      checkForAlignment(true);
    }

//    aCanv.intMouseEnteredX=-1;
//    aCanv.intMouseEnteredY=-1;

    aCanv.intMouseSelectedX=-1;
    aCanv.intMouseSelectedY=-1;

    aCanv.intMouseMovesLeft=intAntMovesPerTurn;    

    lblMoves.setText(String.valueOf(aCanv.intMouseMovesLeft));

    aCanv.repaint();
  }

//Directions
//0=North
//1=East
//2=South
//3=West
  public int checkForAlignmentDirection(int intDirection, int intX, int intY, boolean blnAligned[][]) {
    int intAnts=0;

    if(intDirection==0) {
      int intColor=aCanv.intOccupied[intX][intY];

      int intMatchNorth=intY-1;
      for(;intMatchNorth>=0;intMatchNorth--) {
        if(aCanv.blnOccupied[intX][intMatchNorth]) {
          if(aCanv.intOccupied[intX][intMatchNorth]!=intColor) {
            break;
          }
        }
        else {
          break;
        }
      }
      ++intMatchNorth;


      int intVerticalAlignment=intY-intMatchNorth+1;

      if(intVerticalAlignment>=intMinimumAntAlignment) {
        for(int iz=intMatchNorth;iz<=intY;iz++) {
          if(!blnAligned[intX][iz]) {
            blnAligned[intX][iz]=true;

            ++intAnts;
          }
        }
      }


/*
      for(int iz=intMatchNorth;iz<=intY;iz++) {
        if(!blnAligned[intX][iz]) {
          blnAligned[intX][iz]=true;

          ++intAnts;
        }
      }
*/
    }
    else if(intDirection==1) {
      int intColor=aCanv.intOccupied[intX][intY];

      int intMatchEast=intX+1;
      for(;intMatchEast<aCanv.blnOccupied.length;intMatchEast++) {
        if(aCanv.blnOccupied[intMatchEast][intY]) {
          if(aCanv.intOccupied[intMatchEast][intY]!=intColor) {
            break;
          }
        }
        else {
          break;
        }
      }
      --intMatchEast;


      int intHorizontalAlignment=intMatchEast-intX+1;

      if(intHorizontalAlignment>=intMinimumAntAlignment) {
        for(int iz=intX;iz<=intMatchEast;iz++) {
          if(!blnAligned[iz][intY]) {
            blnAligned[iz][intY]=true;

            ++intAnts;
          }
        }
      }


/*
      for(int iz=intX;iz<=intMatchEast;iz++) {
        if(!blnAligned[iz][intY]) {
          blnAligned[iz][intY]=true;

          ++intAnts;
        }
      }
*/
    }
    else if(intDirection==2) {
      int intColor=aCanv.intOccupied[intX][intY];

      int intMatchSouth=intY+1;
      for(;intMatchSouth<aCanv.blnOccupied[0].length;intMatchSouth++) {
        if(aCanv.blnOccupied[intX][intMatchSouth]) {
          if(aCanv.intOccupied[intX][intMatchSouth]!=intColor) {
            break;
          }
        }
        else {
          break;
        }
      }
      --intMatchSouth;

      int intVerticalAlignment=intMatchSouth-intY+1;

      if(intVerticalAlignment>=intMinimumAntAlignment) {
        for(int iz=intY;iz<=intMatchSouth;iz++) {
          if(!blnAligned[intX][iz]) {
            blnAligned[intX][iz]=true;

            ++intAnts;
          }
        }
      }


/*
      for(int iz=intY;iz<=intMatchSouth;iz++) {
        if(!blnAligned[intX][iz]) {
          blnAligned[intX][iz]=true;

          ++intAnts;
        }
      }
*/
    }
    else if(intDirection==3) {
      int intColor=aCanv.intOccupied[intX][intY];

      int intMatchWest=intX-1;
      for(;intMatchWest>=0;intMatchWest--) {
        if(aCanv.blnOccupied[intMatchWest][intY]) {
          if(aCanv.intOccupied[intMatchWest][intY]!=intColor) {
            break;
          }
        }
        else {
          break;
        }
      }
      ++intMatchWest;

      int intHorizontalAlignment=intX-intMatchWest+1;

      if(intHorizontalAlignment>=intMinimumAntAlignment) {
        for(int iz=intMatchWest;iz<=intX;iz++) {
          if(!blnAligned[iz][intY]) {
            blnAligned[iz][intY]=true;

            ++intAnts;
          }
        }
      }


/*
      for(int iz=intMatchWest;iz<=intX;iz++) {
        if(!blnAligned[iz][intY]) {
          blnAligned[iz][intY]=true;

          ++intAnts;
        }
      }
*/
    }

    int intPoints=Integer.parseInt(lblPoints.getText());

    intPoints+=(intAnts*intPointsPerAnt);

    lblPoints.setText(String.valueOf(intPoints));

    return intAnts;
  }

  class AntCanvas extends Canvas {
    int intSquareWidth=-1;
    int intSquaresHorizontal=10;
    int intSquaresVertical=10;

    boolean blnOccupied[][]=new boolean[intSquaresHorizontal][intSquaresVertical];
    int intOccupied[][]=new int[intSquaresHorizontal][intSquaresVertical];

    int intMouseEnteredX=-1;
    int intMouseEnteredY=-1;
//    int intLastMouseEnteredX=-1;
//    int intLastMouseEnteredY=-1;

/*
    boolean blnChangedMouseEntered=false;
    int intLastMouseEnteredX=-1;
    int intLastMouseEnteredY=-1;
*/

    int intMouseSelectedX=-1;
    int intMouseSelectedY=-1;

    int intMouseMovesLeft=intAntMovesPerTurn;

    BufferedImage bufImage=null;
    Graphics2D graphBufImage=null;

    AntCanvas() {
      super();

      for(int i=0;i<blnOccupied.length;i++) {
        for(int ia=0;ia<blnOccupied[0].length;ia++) {
          blnOccupied[i][ia]=false;
          intOccupied[i][ia]=-1;
        }
      }
    }

    public void initializeSquareWidth() {
      Dimension dimCanvas=getSize();

      bufImage=new BufferedImage(dimCanvas.width, dimCanvas.height, BufferedImage.TYPE_INT_RGB);
      graphBufImage=(Graphics2D)bufImage.getGraphics();
      graphBufImage.setBackground(Color.white);

      int intTempW=dimCanvas.width/intSquaresHorizontal;
      int intTempL=dimCanvas.height/intSquaresVertical;

      if(intTempW<intTempL) {
        intSquareWidth=intTempW;
      }
      else {
        intSquareWidth=intTempL;
      }
    }

    public void paint(Graphics graph) {
      if(intSquareWidth==-1)
        return;

      Font fnt=graphBufImage.getFont();

      FontMetrics fMetr=graphBufImage.getFontMetrics(fnt);

      int fntHeight=fMetr.getHeight();

      int fntWidth=fMetr.stringWidth("A");

      int intFntSize=fntHeight;

      if(fntWidth>intFntSize)
        intFntSize=fntWidth;

      int intFnt=fnt.getSize();

      if(intFntSize<intSquareWidth) {
        while(intFntSize<intSquareWidth) {
          ++intFnt;

          fnt=fnt.deriveFont(Integer.valueOf(intFnt).floatValue());

          graphBufImage.setFont(fnt);

          fMetr=graphBufImage.getFontMetrics(fnt);

          fntHeight=fMetr.getHeight();

          fntWidth=fMetr.stringWidth("A");

          intFntSize=fntHeight;

          if(fntWidth>intFntSize)
            intFntSize=fntWidth;
        }

        --intFnt;

        fnt=fnt.deriveFont(Integer.valueOf(intFnt).floatValue());

        graphBufImage.setFont(fnt);

        fMetr=graphBufImage.getFontMetrics(fnt);

        fntHeight=fMetr.getHeight();

        fntWidth=fMetr.stringWidth("A");

        intFntSize=fntHeight;

        if(fntWidth>intFntSize)
          intFntSize=fntWidth;
      }
      else if(intFntSize>intSquareWidth) {
        while(intFntSize>intSquareWidth) {
          --intFnt;

          fnt=fnt.deriveFont(Integer.valueOf(intFnt).floatValue());

          graphBufImage.setFont(fnt);

          fMetr=graphBufImage.getFontMetrics(fnt);

          fntHeight=fMetr.getHeight();

          fntWidth=fMetr.stringWidth("A");

          intFntSize=fntHeight;

          if(fntWidth>intFntSize)
            intFntSize=fntWidth;
        }

        ++intFnt;

        fnt=fnt.deriveFont(Integer.valueOf(intFnt).floatValue());

        graphBufImage.setFont(fnt);

        fMetr=graphBufImage.getFontMetrics(fnt);

        fntHeight=fMetr.getHeight();

        fntWidth=fMetr.stringWidth("A");

        intFntSize=fntHeight;

        if(fntWidth>intFntSize)
          intFntSize=fntWidth;
      }

/*
      if(blnChangedMouseEntered) {
        blnChangedMouseEntered=false;

        if(intMouseEnteredX<intLastMouseEnteredX) {
          if(intMouseEnteredY<intLastMouseEnteredY) {
            int intCX=intMouseEnteredX*intSquareWidth;
            int intCY=intMouseEnteredY*intSquareWidth;

            int intCWidth=intLastMouseEnteredX*intSquareWidth-intCX;
            int intCHeight=intLastMouseEnteredY*intSquareWidth-intCY;

            graphBufImage.clearRect(intCX-1, intCY-1, intCWidth+2, intCHeight+2);

            graphBufImage.setClip(intCX-1, intCY-1, intCWidth+2, intCHeight+2);
          }
          else {
            int intCX=intMouseEnteredX*intSquareWidth;
            int intCY=intLastMouseEnteredY*intSquareWidth;

            int intCWidth=intLastMouseEnteredX*intSquareWidth-intCX;
            int intCHeight=intMouseEnteredY*intSquareWidth-intCY;

            graphBufImage.clearRect(intCX-1, intCY-1, intCWidth+2, intCHeight+2);

            graphBufImage.setClip(intCX-1, intCY-1, intCWidth+2, intCHeight+2);
          }
        }
        else {
          if(intMouseEnteredY<intLastMouseEnteredY) {
            int intCX=intLastMouseEnteredX*intSquareWidth;
            int intCY=intMouseEnteredY*intSquareWidth;

            int intCWidth=intMouseEnteredX*intSquareWidth-intCX;
            int intCHeight=intLastMouseEnteredY*intSquareWidth-intCY;

            graphBufImage.clearRect(intCX-1, intCY-1, intCWidth+2, intCHeight+2);

            graphBufImage.setClip(intCX-1, intCY-1, intCWidth+2, intCHeight+2);
          }
          else {
            int intCX=intLastMouseEnteredX*intSquareWidth;
            int intCY=intLastMouseEnteredY*intSquareWidth;

            int intCWidth=intMouseEnteredX*intSquareWidth-intCX;
            int intCHeight=intMouseEnteredY*intSquareWidth-intCY;

            graphBufImage.clearRect(intCX-1, intCY-1, intCWidth+2, intCHeight+2);

            graphBufImage.setClip(intCX-1, intCY-1, intCWidth+2, intCHeight+2);
          }
        }
      }
      else {
        graphBufImage.clearRect(0, 0, getSize().width, getSize().height);

        graphBufImage.setClip(0, 0, getSize().width, getSize().height);
      }
*/

/*
      if(blnChangedMouseEntered) {
        blnChangedMouseEntered=false;

//System.out.println("true");

//System.out.println("X0:"+intMouseEnteredX+", Y0:"+intMouseEnteredY);
//System.out.println("X1:"+intLastMouseEnteredX+", Y1:"+intLastMouseEnteredY);

        if(intMouseEnteredX<intLastMouseEnteredX) {
          if(intMouseEnteredY<intLastMouseEnteredY) {
//System.out.println("true0");
            int intCX=intMouseEnteredX*intSquareWidth;
            int intCY=intMouseEnteredY*intSquareWidth;

            int intCWidth=intLastMouseEnteredX*intSquareWidth-intCX;
            int intCHeight=intLastMouseEnteredY*intSquareWidth-intCY;

System.out.println("SW:"+intSquareWidth);
System.out.println("CW:"+intCWidth);
System.out.println("CH:"+intCHeight);

            graphBufImage.clearRect(intCX-1, intCY-1, intCWidth+1*2, intCHeight+1*2);

//            graphBufImage.setClip(intCX-1, intCY-1, intCWidth+1*2, intCHeight+1*2);
          }
          else {
//System.out.println("true1");
            int intCX=intMouseEnteredX*intSquareWidth;
            int intCY=intLastMouseEnteredY*intSquareWidth;

            int intCWidth=intLastMouseEnteredX*intSquareWidth-intCX;
            int intCHeight=intMouseEnteredY*intSquareWidth-intCY;

            graphBufImage.clearRect(intCX-1, intCY-1, intCWidth+1*2, intCHeight+1*2);

//            graphBufImage.setClip(intCX-1, intCY-1, intCWidth+1*2, intCHeight+1*2);
          }
        }
        else {
          if(intMouseEnteredY<intLastMouseEnteredY) {
//System.out.println("true2");
            int intCX=intLastMouseEnteredX*intSquareWidth;
            int intCY=intMouseEnteredY*intSquareWidth;

            int intCWidth=intMouseEnteredX*intSquareWidth-intCX;
            int intCHeight=intLastMouseEnteredY*intSquareWidth-intCY;

            graphBufImage.clearRect(intCX-1, intCY-1, intCWidth+1*2, intCHeight+1*2);

//            graphBufImage.setClip(intCX-1, intCY-1, intCWidth+1*2, intCHeight+1*2);
          }
          else {
//System.out.println("true3");
            int intCX=intLastMouseEnteredX*intSquareWidth;
            int intCY=intLastMouseEnteredY*intSquareWidth;

            int intCWidth=intMouseEnteredX*intSquareWidth-intCX;
            int intCHeight=intMouseEnteredY*intSquareWidth-intCY;

            graphBufImage.clearRect(intCX-1, intCY-1, intCWidth+1*2, intCHeight+1*2);

//            graphBufImage.setClip(intCX-1, intCY-1, intCWidth+1*2, intCHeight+1*2);
          }
        }
      }
      else {
        graphBufImage.clearRect(0, 0, getSize().width, getSize().height);
      }
*/

      graphBufImage.clearRect(0, 0, getSize().width, getSize().height);

      for(int i=0;i<intSquaresHorizontal;i++) {
        for(int ia=0;ia<intSquaresVertical;ia++) {
          if(blnOccupied[i][ia]) {
            int intHorizontalDisplacement=i*intSquareWidth;
            int intVerticalDisplacement=ia*intSquareWidth;

            int intMiddlePoint=intSquareWidth/2;

            Color clr=ANT_COLORS[intOccupied[i][ia]];

            graphBufImage.setColor(clr);

            graphBufImage.drawString("A", intHorizontalDisplacement+intMiddlePoint-fntWidth/2, intVerticalDisplacement+intMiddlePoint+fntHeight/2);
          }
        }
      }

      graphBufImage.setColor(Color.red);

      if(intMouseEnteredX!=-1 & intMouseEnteredY!=-1) {
        int intHorizontalDisplacement=intMouseEnteredX*intSquareWidth;
        int intVerticalDisplacement=intMouseEnteredY*intSquareWidth;

        if(intVerticalDisplacement==0)
          intVerticalDisplacement=1;

        graphBufImage.drawLine(intHorizontalDisplacement, intVerticalDisplacement, intHorizontalDisplacement+intSquareWidth, intVerticalDisplacement);
        graphBufImage.drawLine(intHorizontalDisplacement, intVerticalDisplacement, intHorizontalDisplacement, intVerticalDisplacement+intSquareWidth);
        graphBufImage.drawLine(intHorizontalDisplacement+intSquareWidth, intVerticalDisplacement+intSquareWidth, intHorizontalDisplacement, intVerticalDisplacement+intSquareWidth);
        graphBufImage.drawLine(intHorizontalDisplacement+intSquareWidth, intVerticalDisplacement+intSquareWidth, intHorizontalDisplacement+intSquareWidth, intVerticalDisplacement);
      }

      graphBufImage.setColor(Color.green);

      if(intMouseSelectedX!=-1 & intMouseSelectedY!=-1) {
        int intHorizontalDisplacement=intMouseSelectedX*intSquareWidth;
        int intVerticalDisplacement=intMouseSelectedY*intSquareWidth;

        if(intVerticalDisplacement==0)
          intVerticalDisplacement=1;

        graphBufImage.drawLine(intHorizontalDisplacement, intVerticalDisplacement, intHorizontalDisplacement+intSquareWidth, intVerticalDisplacement);
        graphBufImage.drawLine(intHorizontalDisplacement, intVerticalDisplacement, intHorizontalDisplacement, intVerticalDisplacement+intSquareWidth);
        graphBufImage.drawLine(intHorizontalDisplacement+intSquareWidth, intVerticalDisplacement+intSquareWidth, intHorizontalDisplacement, intVerticalDisplacement+intSquareWidth);
        graphBufImage.drawLine(intHorizontalDisplacement+intSquareWidth, intVerticalDisplacement+intSquareWidth, intHorizontalDisplacement+intSquareWidth, intVerticalDisplacement);
      }

      graph.drawImage(bufImage, 0, 0, null);
    }
  }

  class XandY {
    int intX=-1;
    int intY=-1;

    XandY(int intX, int intY) {
      this.intX=intX;
      this.intY=intY;
    }
  }
}